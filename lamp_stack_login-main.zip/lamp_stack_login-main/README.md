# Lamp Stack CRUD

Becoming familiar with the LAMP stack by building a simple website for creating and managing user accounts.

-Brian Moon

## Create User Account
<img width="1162" alt="create" src="https://user-images.githubusercontent.com/25870426/130092052-6a6fb9ba-fe71-4e7f-b12d-ba52aeb04b22.png">

## Read User Account
<img width="1165" alt="read" src="https://user-images.githubusercontent.com/25870426/130092076-8fe95a17-beee-4451-a169-dbca5b6bbf1a.png">

## Update User Account
<img width="1164" alt="update" src="https://user-images.githubusercontent.com/25870426/130092102-55202c37-66f9-42f9-b94b-246d864436c7.png">

## Delete User Account
<img width="1164" alt="delete" src="https://user-images.githubusercontent.com/25870426/130092130-a7b452e8-7ce8-466e-a106-c846f454aa1d.png">
